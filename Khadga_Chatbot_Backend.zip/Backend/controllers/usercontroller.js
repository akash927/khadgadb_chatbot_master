const mongoose = require("mongoose");
const User = mongoose.model("User");

exports.chat = async (req, res) => {
  const { query, reply } = req.body;
  
  const userExists = await User.findOne({query : req.body.query});
    if (!userExists) {
      throw "query does not exist";
      return res.err;
    } else {
      console.log("You: " +userExists.query);
      console.log("Bot: " +userExists.reply);
      res.json({
        message: "Bot:  " +userExists.reply,
      });
    } 
    return userExists;
};


