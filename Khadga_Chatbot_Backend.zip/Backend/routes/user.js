const router = require("express").Router();
const { catchErrors } = require("../handlers/errorHandlers");
const userController = require("../controllers/userController");

router.post("/chat", catchErrors(userController.chat));

module.exports = router;
