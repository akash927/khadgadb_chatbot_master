const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    query: {
      type: String,
      required: "query is required!",
    },
    reply: {
      type: String,
      required: "Reply is required!",
    },
},
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("User", userSchema);
