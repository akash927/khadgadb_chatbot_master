import React from "react";
import axios from "axios";
import makeToast from "../Toaster";


const chatPage = (props) => {
  const queryRef = React.createRef();
 // const replyRef = React.createRef();

  const chatUser = (props) => {
    const query = queryRef.current.value;
    //const reply = replyRef.current.value;
    
    axios
      .post("http://localhost:8000/user/chat", {
        query,
        //reply
      })
      .then((response) => {
        makeToast("success", response.data.message);
      })
      
      .catch((err) => {
         console.log(err);
        if (
          err &&
          err.response &&
          err.response.data &&
          err.response.data.message
        )
          makeToast("error", err.response.data.message);
          
      });

      
  };

  return (
    <div className="chatPage">
      <div className = "cardTop">
        <div className = "left_title">Khadga</div>
        <div className = "right_title">The Online Chatbot</div>
      </div>
      <div className="chatroomSection">
        <div className="face"></div>
        <div className="chatroomContent">
        <div className="chatroomActions">
          <div>
            <input
              type="query"
              name="query"
              placeholder="Say something!"
              ref={queryRef}
              class = "text"
            />
          </div>
          <div>
            <button className="join" onClick={chatUser}>
                Send
            </button> 
          </div>
        </div>
      </div>
    </div>
    <div className = "cardFooter FooterText">
    For any discrepancies, please contact:<br></br>
      Akash V: akashvraghavan@gmail.com<br></br>
      Anurag.R.Simha: anurag.rsimha@gmail.com<br></br>
      Achyuta B Mudhol: achyuta1210@gmail.com<br></br>
    </div>
    </div>
  );
};

export default chatPage;
