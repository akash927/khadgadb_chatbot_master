import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import ChatPage from "./Pages/ChatPage";

function App() {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="" component={ChatPage} exact />
      </Switch>
    </BrowserRouter>
  );
}

export default App;
